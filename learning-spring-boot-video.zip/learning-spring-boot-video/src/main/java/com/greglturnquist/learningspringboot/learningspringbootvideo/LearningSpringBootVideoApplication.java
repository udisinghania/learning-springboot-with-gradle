package com.greglturnquist.learningspringboot.learningspringbootvideo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningSpringBootVideoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningSpringBootVideoApplication.class, args);
	}

}
